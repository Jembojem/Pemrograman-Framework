<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class User extends BaseController
{
    public function index()
    {
		$model = new UserModel();
    	$kunci = $this->request->getVar('cari');

        if ($kunci) {
            $query = $model->pencarian($kunci);
            $jumlah = "Pencarian dengan nama <B>$kunci</B>";
        } else {
            $query = $model;
            $jumlah = "";
        }

        $data['pengguna'] = $query->paginate(10);
        $data['jumlah'] = $jumlah;

        echo view('user',$data);
    }

    public function detail($nama)
    {
		$userModel = new UserModel();
        $data['det'] = $userModel->where(['nama' => $nama])->first();

        echo view('detail', $data);
    }
}
