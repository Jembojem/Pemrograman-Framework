<?= $this->extend("layout/layout") ?>
<?= $this->section("content") ?>

<div class="container-fluid">
<div class="row">
<div class="col-xl-4">
    <!-- Profile picture card-->
    <div class="card mb-4 mb-xl-0">
        <div class="card-header">Profile Picture</div>
        <div class="card-body text-center">
            <!-- Profile picture image-->
            <img class="img-account-profile rounded-circle mb-2" src="<?= base_url()?>/img/undraw_profile.svg"
                alt="" />
            <!-- Profile picture help block-->
            <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
            <!-- Profile picture upload button-->
            <button class="btn btn-primary" type="button">Upload new image</button>
        </div>
    </div>
</div>
<div class="col-xl-8">
    <!-- Account details card-->
    <div class="card mb-4">
        <div class="card-header">Account Details</div>
        <div class="card-body">
            <form>
                <!-- Form Group (username)-->
                <div class="mb-3">
                    <label class="small mb-1" for="inputUsername">Username </label>
                    <input class="form-control" id="inputUsername" type="text" placeholder="Enter your username"
                        value="<?= $det['nama']?>" />
                </div>
                <!-- Form Group (Alamat)-->
                <div class="mb-3">
                    <label class="small mb-1" for="inputAlamat">Alamat </label>
                    <input class="form-control" id="inputAlamat" type="text" placeholder="Enter your Alamat"
                        value="<?= $det['alamat']?>" />
                </div>
                <!-- Form Row        -->
                <!-- Form Row-->
                <div class="row gx-3 mb-3">
                    <!-- Form Group (phone number)-->
                    <div class="col-md-6">
                        <label class="small mb-1" for="inputTpt">Tempat Lahir</label>
                        <input class="form-control" id="inputTpt" type="text" placeholder="Enter your phone number"
                            value="<?= $det['tempat_lahir']?>" />
                    </div>
                    <!-- Form Group (birthday)-->
                    <div class="col-md-6">
                        <label class="small mb-1" for="inputBirthday">Tanggal Lahir</label>
                        <input class="form-control" id="inputBirthday" type="text" name="birthday"
                            placeholder="Enter your birthday" value="<?= $det['tanggal_lahir']?>" />
                    </div>
                </div>
                <!-- Form Group (email address)-->
                <div class="mb-3">
                    <label class="small mb-1" for="inputTel">Telepon</label>
                    <input class="form-control" id="inputTel" type="tel"
                        placeholder="Enter your email address" value="<?= $det['telepon']?>" />
                </div>
                
                <!-- Save changes button-->
                <button class="btn btn-primary" type="button">Save changes</button>
            </form>
        </div>
    </div>
</div>
</div>
</div>


<?= $this->Endsection("content") ?>