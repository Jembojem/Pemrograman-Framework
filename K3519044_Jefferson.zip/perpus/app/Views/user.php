<?= $this->extend("layout/layout") ?>
<?= $this->section("content") ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Anggota</h6>
        </div>
        <div class="card-body">
        <div>
    		<?php echo $jumlah; ?>
    	</div>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Jenis Kelamin</th>
                            <th>Telepon</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $x = 0 ; foreach ($pengguna as $row):?>
                        <tr>
                            <td><?= $x+1 ?></td>
                            <td><?= $row['nama'] ?></td>
                            <td><?= $row['alamat'] ?></td>
                            <td><?= $row['tempat_lahir'] ?></td>
                            <td><?= $row['tanggal_lahir'] ?></td>
                            <td><?php if ($row['jenis_kelamin'] == 1) {echo "Laki-laki";} else if ($row['jenis_kelamin'] == 2){echo "Perempuan";} ?></td>
                            <td><?= $row['telepon'] ?></td>
                            <td>
                                <a href="<?= base_url() ?>/user/detail/<?= $row['nama'] ?>"
                                    class="btn btn-primary btn-sm">Ubah</a>
                            </td>
                        </tr>
                        <?php $x++ ; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->


<?= $this->Endsection("content") ?>